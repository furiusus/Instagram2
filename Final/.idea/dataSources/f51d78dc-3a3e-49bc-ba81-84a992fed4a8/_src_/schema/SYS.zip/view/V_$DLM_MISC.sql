CREATE VIEW V_$DLM_MISC AS select "STATISTIC#","NAME","VALUE" from v$dlm_misc
/
