CREATE VIEW V_$FIXED_TABLE AS select "NAME","OBJECT_ID","TYPE","TABLE_NUM" from v$fixed_table
/
