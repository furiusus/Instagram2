CREATE VIEW V_$LOGMNR_STATS AS select "SESSION_ID","NAME","VALUE" from v$logmnr_stats
/
