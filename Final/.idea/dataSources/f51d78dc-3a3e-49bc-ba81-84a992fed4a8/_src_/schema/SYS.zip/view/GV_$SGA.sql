CREATE VIEW GV_$SGA AS select "INST_ID","NAME","VALUE" from gv$sga
/
