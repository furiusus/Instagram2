CREATE VIEW V_$ACTIVE_SESS_POOL_MTH AS select "NAME" from v$active_sess_pool_mth
/
