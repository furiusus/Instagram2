CREATE VIEW V_$SESSTAT AS select "SID","STATISTIC#","VALUE" from v$sesstat
/
