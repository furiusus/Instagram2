CREATE VIEW V_$PX_BUFFER_ADVICE AS select "STATISTIC","VALUE" from v$px_buffer_advice
/
