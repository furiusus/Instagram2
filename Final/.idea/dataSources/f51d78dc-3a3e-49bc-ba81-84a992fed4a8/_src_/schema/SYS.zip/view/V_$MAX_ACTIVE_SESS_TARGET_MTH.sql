CREATE VIEW V_$MAX_ACTIVE_SESS_TARGET_MTH AS select "NAME" from v$max_active_sess_target_mth
/
