CREATE VIEW V_$OPTION AS select "PARAMETER","VALUE" from v$option
/
